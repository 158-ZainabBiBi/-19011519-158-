package com.webservice.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebServiceApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(SpringBootWebServiceApplication.class, args);
	}

}
